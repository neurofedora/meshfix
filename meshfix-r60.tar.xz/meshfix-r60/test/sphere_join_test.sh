#!/bin/sh
../meshfix sphere1.off sphere2.off --shells 2 -j 0 --no-clean -o sphere_join_test_result
