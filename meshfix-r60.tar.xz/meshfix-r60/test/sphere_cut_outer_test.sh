#!/bin/sh
../meshfix sphere1.off sphere2.off -a 2.0 --shells 2 --cut-outer 0 -o sphere_cut_outer_result
