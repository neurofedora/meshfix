#!/bin/sh
../meshfix sphere1.off sphere3_dented.off -a 2.0 --shells 2 --decouple-inin 0 -o sphere_decouple_inin_result
