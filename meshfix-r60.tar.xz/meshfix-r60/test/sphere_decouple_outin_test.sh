#!/bin/sh
../meshfix sphere1.off sphere2.off --shells 2 --decouple-outin 0 -o sphere_decouple_outin_result
