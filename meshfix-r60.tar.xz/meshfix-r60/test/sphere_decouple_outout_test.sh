#!/bin/sh
../meshfix sphere3_dented.off sphere1.off --shells 2 --decouple-outout 10 -o sphere_decouple_outout_result
